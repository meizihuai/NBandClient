
var score = document.createElement('div')
score.className = 'scoreBg'
score.innerHTML = `
<div class="scoreBox">
    <div>
        <h2>视频评分 <img class='close' src='images/关闭.svg' ></h2>
    </div>
    <div class='score'>
        <div class='score-expression'></div>
    </div>
    <div class='result'>
        <button>提交</button>
        <div class='result-score'></div>
    </div>
</div>
`
document.body.append(score)

$('#gotoScore').on('click', function () {
    // 弹窗显示
    $('.scoreBg').show();
})

// 关闭按钮
$('.close').on('click', function () {
    // 弹窗隐藏
    $('.scoreBg').hide();
})

// 点击背景隐藏
$('.scoreBg').on('click', function (e) {
    console.log(e.target)
    if (e.target == $('.scoreBg')[0]) {
        // 弹窗隐藏
        $('.scoreBg').hide();
    }

})


jQuery(document).ready(function ($) {
    $('.score').score();
    $('.result button').on('click', function () {
        $('.score').children('[class^="score-"]').each(function (index, el) {
            var l = $(el).children().attr('active-level');
            console.log('分数', l, '用于提交后台')
        })
    })
});